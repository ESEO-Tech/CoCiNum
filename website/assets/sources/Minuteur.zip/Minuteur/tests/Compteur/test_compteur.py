
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import Timer

@cocotb.test()
def run(dut):
    clk = Clock(dut.clk, 1, "ms")
    cocotb.fork(clk.start())

    dut.reset  = 1
    dut.inc    = 1
    dut.dec    = 0

    yield Timer(100, "us")

    dut.reset  = 0

    yield Timer(15, "ms")

    dut.inc = 0

    yield Timer(5, "ms")

    dut.dec = 1

    yield Timer(20, "ms")
