
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import Timer

@cocotb.test()
def run(dut):
    clk = Clock(dut.clk, 1, "ms")
    cocotb.fork(clk.start())

    dut.reset  = 1
    dut.bouton = 0

    yield Timer(100, "us")

    dut.reset = 0

    yield Timer(5100, "us")

    dut.bouton = 1

    yield Timer(7000, "us")

    dut.bouton = 0

    yield Timer(3000, "us")
