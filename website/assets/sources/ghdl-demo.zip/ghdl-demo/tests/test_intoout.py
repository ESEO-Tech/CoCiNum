import cocotb
from cocotb.triggers import Timer

import tkinter as tk
from datetime import datetime, timedelta

led_color_on  = "lime"
led_color_off = "dark slate gray"

refresh_time = timedelta(milliseconds=40)

class Gui:
	def __init__(self, dut):
		self.dut = dut

		self.root = tk.Tk()
		self.root.protocol("WM_DELETE_WINDOW", self.on_close)

		btn = tk.Button(self.root, text="Click here")
		btn.pack(side=tk.TOP)
		btn.bind("<ButtonPress>", self.on_press)
		btn.bind("<ButtonRelease>", self.on_release)

		self.canvas = tk.Canvas(self.root, width=100, height=100, bg="black", relief="flat")
		self.canvas.pack(side=tk.BOTTOM)
		self.led = self.canvas.create_oval(10, 10, 90, 90, fill=led_color_off)

		self.state = 0
		self.closed = False
		self.last_update = datetime.now()

	def on_close(self):
		self.root.quit()
		self.closed = True

	def on_press(self, evt):
		self.state = 1

	def on_release(self, evt):
		self.state = 0

	def update(self):
		t = datetime.now()
		delta = t - self.last_update

		if delta >= refresh_time:
			self.last_update = t
			self.dut.x = self.state
			self.canvas.itemconfig(self.led, fill=led_color_on if self.dut.y.value.binstr == '1' else led_color_off)

		self.root.update()

@cocotb.test()
def run(dut):
	gui = Gui(dut)

	dut.x = 0

	while not gui.closed:
		yield Timer(250, "us")
		gui.update()

